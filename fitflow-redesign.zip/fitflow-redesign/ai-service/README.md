# AI Service

Target: Python + FastAPI.

Responsibilities: personalized workout inference, recommendation explanation metadata, and meal/nutrition inference. The AI service should receive only the data needed for each inference request.
