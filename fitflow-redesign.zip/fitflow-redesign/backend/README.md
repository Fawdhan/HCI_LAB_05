# Backend

Target: NestJS TypeScript application API.

Planned modules: auth integration, users/profiles, workouts, progress, nutrition, community, privacy, notifications, WebSocket gateway and audit events.
