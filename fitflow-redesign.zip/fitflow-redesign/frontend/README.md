# Frontend

Target: Flutter application for iOS, Android and web.

Planned feature modules: Home Dashboard, AI Workout Planner, Active Workout, Progress, Community/Challenges and Nutrition Logger.
